# SQL Directory

This folder is for storing raw SQL files, custom queries, database scripts, or exports.

- Place any `.sql` files or database scripts here for reference or manual database operations.
- Use this folder for sharing or versioning SQL outside of Laravel migrations.
