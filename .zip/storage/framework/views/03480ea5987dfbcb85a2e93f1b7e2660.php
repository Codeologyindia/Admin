

<?php $__env->startSection('title', 'Ayushman Card Payment'); ?>
<?php $__env->startSection('topbar-title', 'Ayushman Card Payment'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="card shadow-sm border-0 mb-4">
        <div class="card-body">
            <h4 class="fw-bold mb-3">Payment for: <?php echo e($card->patient_name); ?></h4>
            <form id="paymentFormAyushman" method="POST" action="<?php echo e(route('admin.ayushman-card-query.update', $card->id)); ?>">
                <?php echo csrf_field(); ?>
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label class="form-label">Total Amount</label>
                        <input type="text" class="form-control" value="<?php echo e($card->amount); ?>" readonly>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Paid Amount</label>
                        <input type="text" class="form-control" value="<?php echo e($card->paid_amount); ?>" readonly>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Left Amount</label>
                        <input type="text" class="form-control" value="<?php echo e($card->amount - $card->paid_amount); ?>" readonly>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4">
                        <label class="form-label">Add Payment Amount</label>
                        <input type="number" min="1" name="paid_amount" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Transaction ID</label>
                        <input type="text" name="payment_id" class="form-control">
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Add Payment</button>
                <a href="<?php echo e(route('admin.ayushman-card-query')); ?>" class="btn btn-secondary ms-2">Back</a>
            </form>
        </div>
    </div>
    <div class="card shadow-sm border-0">
        <div class="card-body">
            <h5 class="fw-bold mb-3">Ayasman Logs</h5>
            <?php if($logs->count()): ?>
                <div class="table-responsive">
                    <table class="table table-bordered table-sm mb-0">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Amount</th>
                                <th>Transaction ID</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($log->created_at ? $log->created_at->format('Y-m-d H:i') : ''); ?></td>
                                    <td><?php echo e($log->amount); ?></td>
                                    <td><?php echo e($log->payment_id); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-muted">No payment logs found.</div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Softwhere\resources\views\admin\ayushman-card-payment.blade.php ENDPATH**/ ?>