

<?php $__env->startSection('title', 'Hospital List'); ?>
<?php $__env->startSection('topbar-title', 'Hospital List'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card shadow-sm border-0 mb-4" style="border-radius:1rem;">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4 class="fw-bold mb-0">Hospital/Clinic List</h4>
                <a href="<?php echo e(route('admin.hospital.add')); ?>" class="btn btn-success px-4">
                    <i class="bi bi-plus-lg"></i> Add Hospital
                </a>
            </div>
            
            <form method="GET" action="<?php echo e(route('admin.hospital')); ?>" class="row g-2 align-items-end mb-4 bg-light p-3 rounded shadow-sm">
                <div class="col-md-2">
                    <label class="form-label mb-1 fw-semibold">Name</label>
                    <input type="text" name="name" value="<?php echo e(request('name')); ?>" class="form-control form-control-sm" placeholder="Name">
                </div>
                <div class="col-md-2">
                    <label class="form-label mb-1 fw-semibold">Type</label>
                    <select name="type" class="form-select form-select-sm">
                        <option value="">All</option>
                        <option value="Hospital" <?php echo e(request('type')=='Hospital' ? 'selected' : ''); ?>>Hospital</option>
                        <option value="Clinic" <?php echo e(request('type')=='Clinic' ? 'selected' : ''); ?>>Clinic</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label mb-1 fw-semibold">City</label>
                    <input type="text" name="city" value="<?php echo e(request('city')); ?>" class="form-control form-control-sm" placeholder="City">
                </div>
                <div class="col-md-2">
                    <label class="form-label mb-1 fw-semibold">State</label>
                    <input type="text" name="state" value="<?php echo e(request('state')); ?>" class="form-control form-control-sm" placeholder="State">
                </div>
                <div class="col-md-2">
                    <label class="form-label mb-1 fw-semibold">Contact</label>
                    <input type="text" name="contact" value="<?php echo e(request('contact')); ?>" class="form-control form-control-sm" placeholder="Contact">
                </div>
                <div class="col-md-1 text-end d-flex align-items-end gap-1">
                    <button type="submit" class="btn btn-primary btn-sm px-3">Filter</button>
                    <a href="<?php echo e(route('admin.hospital')); ?>" class="btn btn-secondary btn-sm px-3">Reset</a>
                </div>
            </form>
            
            <div class="table-responsive">
                <table class="table table-bordered table-hover align-middle mb-0" style="background:#fff;">
                    <thead class="table-light">
                        <tr class="align-middle text-center">
                            <th style="width:40px;">#</th>
                            <th>Name</th>
                            <th>Type</th>
                            <th>City</th>
                            <th>State</th>
                            <th>Contact</th>
                            <th>Address</th>
                            <th style="width:80px;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $startIndex = ($hospitals->currentPage() - 1) * $hospitals->perPage() + 1;
                        ?>
                        <?php $__empty_1 = true; $__currentLoopData = $hospitals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hospital): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="text-center text-muted"><?php echo e($startIndex++); ?></td>
                            <td class="fw-semibold"><?php echo e($hospital->hospital_name); ?></td>
                            <td><?php echo e($hospital->type); ?></td>
                            <td><?php echo e($hospital->city); ?></td>
                            <td><?php echo e($hospital->state); ?></td>
                            <td><?php echo e($hospital->contact); ?></td>
                            <td><?php echo e($hospital->address); ?></td>
                            <td class="text-center">
                                <a href="<?php echo e(route('admin.hospital.edit', $hospital->id)); ?>" class="btn btn-sm btn-warning px-2" title="Edit">
                                    <i class="bi bi-pencil"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center text-muted">No records found.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <div class="mt-3">
                <style>
                    .pagination .page-link { font-size: 0.85rem; }
                    .pagination .page-item.active .page-link { background: #232946; border-color: #232946; color: #fff; }
                </style>
                <nav>
                    <ul class="pagination justify-content-end mb-0">
                        
                        <li class="page-item <?php echo e($currentPage == 1 ? 'disabled' : ''); ?>">
                            <a class="page-link" href="<?php echo e($hospitals->url($currentPage - 1)); ?><?php echo e(request()->getQueryString() ? '&'.request()->getQueryString() : ''); ?>">Prev</a>
                        </li>
                        
                        <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="page-item <?php echo e($currentPage == $page ? 'active' : ''); ?>">
                                <a class="page-link" href="<?php echo e($hospitals->url($page)); ?><?php echo e(request()->getQueryString() ? '&'.request()->getQueryString() : ''); ?>"><?php echo e($page); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        <li class="page-item <?php echo e($currentPage == $lastPage ? 'disabled' : ''); ?>">
                            <a class="page-link" href="<?php echo e($hospitals->url($currentPage + 1)); ?><?php echo e(request()->getQueryString() ? '&'.request()->getQueryString() : ''); ?>">Next</a>
                        </li>
                    </ul>
                </nav>
            </div>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Softwhere\resources\views\admin\hospital.blade.php ENDPATH**/ ?>