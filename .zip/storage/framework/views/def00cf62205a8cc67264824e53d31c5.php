<div>
    <h6 class="fw-bold mb-3 text-primary">
        <i class="bi bi-paperclip"></i> Uploaded Documents
    </h6>
    <div class="row">
        <?php if($otherDocs->count()): ?>
            <?php $__currentLoopData = $otherDocs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $ext = strtolower(pathinfo($doc->file_path, PATHINFO_EXTENSION));
                    $icon = 'bi-file-earmark';
                    if (in_array($ext, ['xls', 'xlsx', 'csv'])) $icon = 'bi-file-earmark-excel text-success';
                    elseif (in_array($ext, ['pdf'])) $icon = 'bi-file-earmark-pdf text-danger';
                    elseif (in_array($ext, ['doc', 'docx'])) $icon = 'bi-file-earmark-word text-primary';
                    elseif (in_array($ext, ['jpg', 'jpeg', 'png', 'gif'])) $icon = 'bi-file-earmark-image text-info';
                ?>
                <div class="col-12 col-md-2 mb-3">
                    <a href="<?php echo e(asset('storage/' . $doc->file_path)); ?>" target="_blank" class="d-flex flex-column align-items-center text-decoration-none border rounded p-3 bg-light h-100 shadow-sm hover-shadow">
                        <i class="bi <?php echo e($icon); ?> fs-1 mb-2"></i>
                        <span class="fw-semibold text-truncate" style="max-width:120px;"><?php echo e($doc->name ?: basename($doc->file_path)); ?></span>
                        <span class="badge bg-secondary mt-2 text-uppercase"><?php echo e($ext); ?></span>
                        <span class="small text-muted mt-1">
                            <?php echo e($doc->created_at ? $doc->created_at->format('Y-m-d') : ''); ?>

                        </span>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="col-12 text-muted">No documents uploaded.</div>
        <?php endif; ?>
    </div>
    <style>
        .hover-shadow:hover {
            box-shadow: 0 4px 16px rgba(34,43,69,0.13);
            background: #f4f8ff;
            transition: box-shadow 0.2s, background 0.2s;
        }
    </style>
</div>
<?php /**PATH C:\xampp\htdocs\Softwhere\resources\views\admin\partials\prescription-files.blade.php ENDPATH**/ ?>